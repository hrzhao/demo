package com.rhcloud.insongr.srv.wechat.common;

public class Constants {
	public final static String MSGTYPE_TEXT = "text";
	public final static String MSGTYPE_LOCATION = "location";
	public final static String MSGTYPE_IMAGE = "image";
}

package com.rhcloud.insongr.srv.wechat.test;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.rhcloud.insongr.srv.wechat.bean.WeChatReqBean;
import com.rhcloud.insongr.srv.wechat.bean.WeChatRespBean;
import com.rhcloud.insongr.srv.yahoo.geocode.ResultSet;
import com.sun.xml.bind.marshaller.CharacterEscapeHandler;

public class JAXBDemo {
	
	public static void main(String[] args) throws JAXBException, MalformedURLException {
		JAXBContext jc = JAXBContext.newInstance(WeChatReqBean.class);
		
		Unmarshaller u = jc.createUnmarshaller();
		String xml = "<xml><ToUserName><![CDATA[gh_217ace14c180]]></ToUserName><FromUserName><![CDATA[ogBAIjybHILFTBCC_Ug8b1teFiYI]]></FromUserName><CreateTime>1358172380</CreateTime><MsgType><![CDATA[text]]></MsgType><Content><![CDATA[天堂]]></Content><MsgId>5833305954430917613</MsgId></xml>";
		WeChatReqBean reqBean = (WeChatReqBean) u.unmarshal(new StringReader(xml));
		System.out.println(reqBean.getContent());
		System.out.println(reqBean.getCreateTime());
		
		System.out.println("-------------------------");
		
		jc = JAXBContext.newInstance(WeChatRespBean.class);
		Marshaller m = jc.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		m.setProperty(CharacterEscapeHandler.class.getName(), new CharacterEscapeHandler() {
			
			@Override
			public void escape(char[] arg0, int arg1, int arg2, boolean arg3,
					Writer arg4) throws IOException {
				arg4.write(arg0, arg1, arg2);
			}
		});
		m.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
		m.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
		WeChatRespBean respBean = new WeChatRespBean();
		respBean.setFromUserName(reqBean.getToUserName());
		respBean.setToUserName(reqBean.getFromUserName());
		respBean.setMsgType("text");
		respBean.setCreateTime(new Date().getTime());
		respBean.setContent("地狱");
		StringWriter ws = new StringWriter();
		m.marshal(respBean, ws);
		System.out.println(ws.toString());
		
//		xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><ResultSet xmlns:ns1=\"http://www.yahooapis.com/v1/base.rng\" version=\"2.0\" xml:lang=\"en-US\"><Error>0</Error><ErrorMessage>No error</ErrorMessage><Locale>en-US</Locale><Found>1</Found><Quality>99</Quality><Result><quality>40</quality><latitude>32.0485</latitude><longitude>118.778969</longitude><offsetlat>32.0485</offsetlat><offsetlon>118.778969</offsetlon><radius>8800</radius><name>32.00512 118.765871</name><line1>32.00512 118.765871, Nanjing</line1><line2></line2><line3>Jiangsu</line3><line4>China</line4><house></house><street></street><xstreet></xstreet><unittype></unittype><unit></unit><postal></postal><neighborhood></neighborhood><city>Nanjing</city><county>Nanjing</county><state>Jiangsu</state><country>China</country><countrycode>CN</countrycode><statecode>32</statecode><countycode></countycode><uzip>2100</uzip><hash></hash><woeid>2137081</woeid><woetype>7</woetype></Result></ResultSet>";
//		jc = JAXBContext.newInstance(ResultSet.class);
//		u = jc.createUnmarshaller();
//		ResultSet rs = (ResultSet) u.unmarshal(new StringReader(xml));
//		System.out.println(rs.getResult().getWoeid());
		
		try {
			String placeUrl = "http://where.yahooapis.com/geocode?location=32.00512+118.765871&gflags=R";
			jc = JAXBContext.newInstance(ResultSet.class);
			u = jc.createUnmarshaller();
			URL url = new URL(placeUrl);
			ResultSet resultSet = (ResultSet) u.unmarshal(url);
			System.out.println(resultSet.getResult().getWoeid());
		} catch (MalformedURLException e) {
		}
		
		
	}
}
